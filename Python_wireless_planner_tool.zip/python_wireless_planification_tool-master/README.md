# python_wireless_planification_tool
<h1>Wifi planification tool</h1>
This is a wireless planification tool writing in the Python programming language and the Tkinter library.
<hr>
<h2>Installation</h2>
The project uses Python version 3 and the tkinter library which can be installed on your system as follows
<code>pip install tkinter</code>
<h2>Execution</h2>
The program's entry point is PythonApplication1, so run that as follows
<code>python PythonApplication1</code>
If you're on a Linux machine, use the following command
<code>python3 PythonApplication1</code>
